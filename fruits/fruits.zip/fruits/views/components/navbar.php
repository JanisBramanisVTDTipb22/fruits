<header>
        <nav>
            <a href="/">Fruits</a>
            <a href="/create">Create a fruit</a>
            <a href="/edit">Edit a fruit</a>
        </nav>
    </header>