<?php

$routes = [
    "/" => "controllers/fruits/index.php",
    "/create" => "views/posts/create.view.php",
    "/edit" => "views/posts/edit.view.php"
];